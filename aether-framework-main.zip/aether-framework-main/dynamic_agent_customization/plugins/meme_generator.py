class MemePlugin:
    def execute(self, topic):
        return f"Here's your meme about {topic}!"